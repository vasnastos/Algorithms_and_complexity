#include "student.h"
#include <algorithm>
student::student(std::string r, int i) :recon(r), id(i) {}
void student::add_lesson(std::string les) { this->lessons.push_back(les); }
std::vector <std::string> student::getExams() { return this->lessons; }
int student::lessons_enrolled_in() { return this->lessons.size(); }
bool student::is_in(std::string les) { return std::count_if(this->lessons.begin(), this->lessons.end(), [les](std::string& st) {return st == les; }) > 0; }
std::ostream& operator<<(std::ostream& os, const student& s)
{
	os << s.recon << "--" << s.id << std::endl;
	for (auto& x : s.lessons)
	{
		os << x << std::endl;
	}
	return os;
}
