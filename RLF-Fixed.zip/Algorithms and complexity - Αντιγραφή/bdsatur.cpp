#include "bdsatur.h"
#include <algorithm> 
#define CHECKFLAG -10

bdsatur::bdsatur(std::vector <std::list <int>>& g, int cls) :graph(g), vertices(g.size()), colorsmax(cls),backtrackfactor(0)
{
	for (int i = 0, t = g.size(); i < t; i++)
	{ 
		saturationlevel.push_back(0);
	} 
	this->maxDegreeVertex(); 
}

bdsatur::~bdsatur() {}

void bdsatur::maxDegreeVertex()
{
	int degree = -1;
	int maxvertex = -1;
	int j = 0;
	for (auto& x : this->graph)
	{
		int sz = x.size();
		if (sz> degree)
		{
			degree = x.size();
			maxvertex = j;
		}
		j++;
	}
	saturationlevel[maxvertex] = INT_MIN;
	for (auto& x : this->graph[maxvertex])
	{
		saturationlevel[x]++;
	}
	this->colors[maxvertex] = 1;//startcolor
}

int bdsatur::saturVertex()
{
	int saturation = -1;
	int saturvertex = -1;
	for (int i = 0, t = this->saturationlevel.size(); i < t; i++)
	{
		if (this->saturationlevel[i] > saturation)
		{
			saturation = this->saturationlevel[i];
			saturvertex = i;
		}
	}
	if (saturvertex==-1)
	{
		return CHECKFLAG;
	}
	backtrack b{ saturvertex,saturation };
	backing.push_back(b);
	this->saturationlevel[saturvertex] = INT_MIN;
	for (auto& x : this->graph[saturvertex])
	{
		saturationlevel[x]++;
	}
	return saturvertex;
}

void bdsatur::refresh()
{
	if (backing.empty()) { return; }
	for (auto& y : backing)
	{
		for (auto& x : this->graph[y.vertex])
		{
			this->saturationlevel[x]--;
		}
		this->saturationlevel[y.vertex] = y.saturation;
	}
	this->backing.clear();
}

bool bdsatur::isSafe(int v, int c)
{
	for (auto& x : this->graph[v])
	{
		if (this->colors[x] == c)
		{
			return false;
		}
	}
	return true;
}

bool bdsatur::graph_coloring(int V)
{
	if (V==0) { return true; }
	if (backtrackfactor <0) { return false; }
	int vertex = saturVertex();
	for (int i = 1; i <= this->colorsmax; i++)
	{
		std::cout << "iteration " << i << "---Vertex:" << vertex << std::endl;
		if (this->isSafe(vertex, i))
		{
			backtrackfactor++;
			this->colors[vertex] = i;
			int next=this->saturVertex();
			if (this->graph_coloring(V - 1))
			{
				return true;
			}
		    this->colors[vertex] = 0;
		}
	}
	if (colors[vertex] == 0) { return false; }
	std::cout << "False statement" << std::endl;
	return false;
}

bool bdsatur::colorgraph(int v)
{
	if (graph_coloring(v))
	{
		return true;
	}
	else
	{
		return false;
	}
}

void bdsatur::printing(std::vector <std::string> &exams)
{
	std::cout << "##################### BDSATUR RESULTS ######################################" << std::endl;
	if (this->colorgraph(exams.size()-1))
	{
		for (auto& x : this->colors)
		{
			std::cout << "\t#Vertex:"<<exams[x.first] <<"->"<< x.second << std::endl;
		}
	}
	else
	{
		std::cout << "Can't not color with " << this->colorsmax << " colors" << std::endl;
	}
	std::cout << "############################################################################" << std::endl;
}