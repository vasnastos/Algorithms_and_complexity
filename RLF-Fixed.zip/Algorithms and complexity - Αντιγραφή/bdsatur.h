#pragma once
#include <list>
#include <map>
#include <iostream>
#include <set>
#include <algorithm>
#include <vector>

struct backtrack
{
	int vertex;
	int saturation;
};

class bdsatur
{
private:
	int backtrackfactor;
	std::vector <std::list <int>> graph;
	std::vector <int> examinees;
	int vertices;
	int colorsmax;
	std::vector <backtrack> backing;
	std::map <int, int> colors;
	std::vector <int> saturationlevel;
	void maxDegreeVertex();
	int saturVertex();
	bool isSafe(int v, int c);
	void refresh();
	bool graph_coloring(int V);
	bool colorgraph(int v);
public:
	bdsatur(std::vector <std::list <int>>& g,int cls);
	~bdsatur();
	void printing(std::vector <std::string> &exams);
};

