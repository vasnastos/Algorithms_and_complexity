#pragma once
#include <iostream>
#include <list>
#include <map>
#include <vector>

using std::map;
using std::vector;

class graph
{
private:
	int* result;
	bool* available;
	int V;
	std::list <int>* adj;
	bool contains(int start,int dest);
public:
	graph(int v);
	~graph();
	void free_temp();
	void add_connection(int s, int d);
	std::list <int>& get_neibourgs(int vertex);
	std::vector <int> first_fit();
	map <int,int> DSatur();
	//RLF
	size_t numofchecks;
	void swap(int& a, int& b);
	void removeElement(vector<int>& A, int i);
	void chooseVertex(vector<int>& X, int& v, int& vPos, vector<int>& Deg);
	void updateX(std::vector<int>& X, std::vector<int>& XDeg, int v, int vPos, std::vector<int>& Y, vector<int>& YDeg, std::vector< vector<bool> >& adjacent, vector<int>& NInY);
	void makeSolution(std::vector< std::vector<int> >& candSol, std::vector<int>& degree, vector<int>& colNode, vector< vector<bool> >& adjacent, int numNodes);
	void rlf();
};

