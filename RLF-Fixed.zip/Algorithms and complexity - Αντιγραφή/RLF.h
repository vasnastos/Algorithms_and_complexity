﻿#pragma once
#include <vector>
#include <iostream>
#include <set>
#include <list>

using std::list;
using std::set;

class RLF
{
private:
	std::vector <list <int>> graph;
	int vertices;
	set <int>  nonneibourghs;
	int* colors;
	int unprocessed;
public:
	RLF(std::vector <std::list<int>>& vlc, int V);
	~RLF() { delete colors; colors = 0; }
	//Εύρεση  Κορυφής με μεγαλύτερο Βαθμό
	int MaxDegreeVertex();

	//Ενημέρωση πίνακα με κορυφές που δεν είναι γείτονες της εξεταζόμενης κορυφής
	void UpdateNonNeibourghs(int cn);

	//Έλεγχος γειτονικότητας δύο κορυφών
	bool is_adjancent(int source,int target);

	//Εύρεση Κορυφής από το set των μη ταξινομιμένων
	int find_NonN_Vertex(int ColorNumber, int& Vic);

	//Εύρεση μέγιστης κορυφής ανάμεσα στις μη-γειτονικές κορυφές με μία κορυφή
	int MaxDegreeInNN();
	std::vector <int> rlf();
};

