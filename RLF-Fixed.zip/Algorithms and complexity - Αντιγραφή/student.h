#pragma once
#include <iostream>
#include <vector>
class student
{
    private:
        std::string recon;
        int id;
        std::vector <std::string> lessons;
    public:
        student(std::string r, int i);
        void add_lesson(std::string les);
        int lessons_enrolled_in();
        bool is_in(std::string les);
        std::vector <std::string> getExams();
        friend std::ostream& operator<<(std::ostream& os, const student& s);
};

