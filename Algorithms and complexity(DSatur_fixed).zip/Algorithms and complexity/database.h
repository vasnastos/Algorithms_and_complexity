#pragma once
#include <string>
#include <vector>
#include "statstruct.cpp"


void open_db();
bool is_in(std::string filename);
void insert_data(std::string f, double d, int mn, int md, int mx, double men, double c);
std::vector <stats> get_records();