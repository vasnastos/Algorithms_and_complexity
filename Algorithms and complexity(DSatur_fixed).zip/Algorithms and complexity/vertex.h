#pragma once
#include <iostream>
#include <vector>
class vertex
{
private:
	std::string code;
	std::vector <int> vertices;
public:
	vertex(std::string &c);
	~vertex();
	size_t collision_counter();
	bool operator<(vertex& v);
	bool operator>(vertex& v);
	void add_vertex(const int& v);
	friend std::ostream& operator<<(std::ostream& os, const vertex& v);
};

