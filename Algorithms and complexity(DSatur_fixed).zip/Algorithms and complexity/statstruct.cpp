#include <iostream>
struct stats
{
	std::string file;
	double density;
	int min, median, max;
	double mean, cv;
};