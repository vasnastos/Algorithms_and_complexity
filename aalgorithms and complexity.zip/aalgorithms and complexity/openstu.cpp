#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath>
#include <vector>
#include "student.h"

//open all input files in order to insert the data
//team up the data and run the algorithms 
//Design the Gui

void stu_f_92(std::vector <student> &students)
{
	std::string line;
	std::ifstream is;
	std::string filename = "yor-f-83.stu";
	is.open(filename, std::ios::in);
	if (!is.is_open())
	{
		std::cerr << "File did not open!!!" << std::endl;
		return;
	}
	std::string word;
	int id = 1;
	while (std::getline(is, line))
	{
		std::istringstream ss(line);
		student s(filename, id);
		while (ss>>word)
		{
			s.add_lesson(word);
		}
		students.push_back(s);
		id++;
	}
	is.close();
}

void show_students(std::vector <student> &sts)
{
	for (auto& y : sts)
	{
		std::cout << "*********************************************************" << std::endl;
		std::cout << y << std::endl;
		std::cout << "*********************************************************"<<std::endl<<std::endl;
	}
}

std::vector <std::string> find_exams(std::vector <student> &students)
{
	std::vector <std::string> exams;
	for (auto& x : students)
	{
		bool found = false;
		std::vector <std::string> exms = x.getExams();
		for (auto& k : exms)
		{
			bool found = false;
			for (auto& x : exams)
			{
				if (k == x)
				{
					found = true;
					break;
				}
			}
			if (!found)
			{
				exams.push_back(k);
			}
		}
	}
	return exams;
}

int find_diff(std::vector <student>& students,std::string n1,std::string n2)
{
	int counter = 0;
	for (auto& x : students)
	{
		if (x.is_in(n1) && x.is_in(n2))
		{
			counter++;
		}
	}
	return counter;
}

void fill_board(std::vector <student> &students,int **board)
{
	std::vector <std::string> exams = find_exams(students);
	const int size = exams.size();
	std::cout <<"Total exams:"<< size << std::endl;
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			for (std::vector <student>::iterator itr = students.begin(); itr != students.end(); itr++)
			{
				if (itr->is_in(exams[i]) && itr->is_in(exams[j]))
				{
					board[i][j] = 1;
					break;
				}
			}
		}
	}
}

int get_sign_ins(std::vector <student>& students)
{
	int counter = 0;
	for (auto& x : students)
	{
		counter += x.lessons_enrolled_in();
	}
	return counter;
}

void fill_zeros(int** brd, int size)
{
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			brd[i][j] = 0;
		}
	}
}

double findCV(int** board, int size)
{
	int summary = 0;
	for (int i = 0; i < size; i++)
	{
		for (int l = 0; l < size; l++)
		{
			if (i == l) continue;
			if (board[i][l] == 1)
			{
				summary++;
			}
		}
	}
	return (double)summary / pow(size,2);
}

int main()
{
	std::vector <student> students;
	stu_f_92(students);
	show_students(students);
	std::vector <std::string> exams = find_exams(students);
	const int size = exams.size();
	std::cout << size << std::endl;
	int** algboard;
	algboard = new int* [size];
	for (int i = 0; i < size; i++)
	{
		algboard[i] = new int[size];
	}
	fill_zeros(algboard, size);
	std::cout << std::endl << "Total students:" << students.size() << std::endl << "Total SignIns:" << get_sign_ins(students) << std::endl;
	fill_board(students,algboard);
	for (int i = 0; i < size; i++)
	{
		std::cout << "**********************************************************************" << std::endl;
		std::cout << "Exam " << i+1 << std::endl;
		for (int j = 0; j < size; j++)
		{
			std::cout << "Exam " << j + 1 << "--" << algboard[i][j] << std::endl;
		}
		std::cout << "***********************************************************************" << std::endl;
	}
	std::cout << std::endl << "Cv factor:" << findCV(algboard, size) << std::endl;
	for (int i = 0; i < size; i++)
	{
		delete[] algboard[i];
	}
	delete[] algboard;
	algboard = 0;
	return 0;
}