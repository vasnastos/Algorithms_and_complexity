#pragma once
#include <list>
#include <map>
#include <iostream>
#include <set>
#include <algorithm>
#include <vector>
class bdsatur
{
private:
	std::vector <std::list <int>> graph;
	int vertices;
	int colorsmax;
	int Flag;
	int counteralgorithm;
	std::map <int, int> colors;
	std::vector <int> saturationlevel;
	void maxDegreeVertex();
	int saturVertex();
	bool isSafe(int v, int c);
	bool graph_coloring();
public:
	bdsatur(std::vector <std::list <int>>& g,int cls);
	~bdsatur();
	void printing(std::vector <std::string> &exams);
};

