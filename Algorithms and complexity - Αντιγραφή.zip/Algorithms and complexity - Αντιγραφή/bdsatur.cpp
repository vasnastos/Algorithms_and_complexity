#include "bdsatur.h"
#include <algorithm> 
#define CHECKFLAG -10




bdsatur::bdsatur(std::vector <std::list <int>>& g, int cls) :graph(g), vertices(g.size()), counteralgorithm(0), colorsmax(cls) { for (int i = 0, t = g.size(); i < t; i++) { saturationlevel.push_back(0); } this->maxDegreeVertex(); this->Flag = g.size(); }
bdsatur::~bdsatur() {}

void bdsatur::maxDegreeVertex()
{
	int degree = -1;
	int maxvertex = -1;
	int j = 0;
	for (auto& x : this->graph)
	{
		int sz = x.size();
		if (sz> degree)
		{
			degree = x.size();
			maxvertex = j;
		}
		j++;
	}
	saturationlevel[maxvertex] = INT_MIN;
	for (auto& x : this->graph[maxvertex])
	{
		saturationlevel[x]++;
	}
	this->Flag--;
	this->colors[maxvertex] = 1;
}

int bdsatur::saturVertex()
{
	int saturation = -1;
	int saturvertex = -1;
	for (int i = 0, t = this->saturationlevel.size(); i < t; i++)
	{
		if (this->saturationlevel[i] > saturation)
		{
			saturation = this->saturationlevel[i];
			saturvertex = i;
		}
	}
	if (saturvertex==-1)
	{
		return CHECKFLAG;
	}
	this->saturationlevel[saturvertex] = INT_MIN;
	for (auto& x : this->graph[saturvertex])
	{
		saturationlevel[x]++;
	}
	this->Flag--;
	return saturvertex;
}

bool bdsatur::isSafe(int v, int c)
{
	for (auto& x : this->graph[v])
	{
		if (this->colors[x] == c)
		{
			return false;
		}
	}
	return true;
}

bool bdsatur::graph_coloring()
{
	if (std::count_if(this->saturationlevel.begin(), this->saturationlevel.end(), [](int& saturation) {return saturation == INT_MIN; }) == this->saturationlevel.size())
	{
		return true;
	}
	int vertex = this->saturVertex();
	if (vertex==CHECKFLAG) { return true; }
	for (int i = 1; i <= this->colorsmax; i++)
	{
		if (this->isSafe(vertex, i))
		{
			this->colors[vertex] = i;
			if (this->graph_coloring())
			{
				return true;
			}
			else {
				return false;
			}
		}
		this->colors[vertex] = INT_MIN;
	}
	return false;
}

void bdsatur::printing(std::vector <std::string> &exams)
{
	std::cout << "##################### BDSATUR RESULTS ######################################" << std::endl;
	if (this->graph_coloring())
	{
		for (auto& x : this->colors)
		{
			std::cout << "\t#Vertex:"<<exams[x.first] <<"->"<< x.second << std::endl;
		}
	}
	else
	{
		std::cout << "Can't not color with " << this->colorsmax << " colors" << std::endl;
	}
	std::cout << "############################################################################" << std::endl;
}