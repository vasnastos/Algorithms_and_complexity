#include "graph.h"
graph::graph(int v) : V(v), adj(new std::list<int>[v]),result(nullptr),available(nullptr) {}
graph::~graph() { delete[] this->adj;}

void graph::add_connection(int s, int d)
{
	adj[s].push_back(d);
}

void graph::free_temp()
{
	delete[] this->result;
	delete[] this->available;
}

std::vector <int> graph::first_fit()
{
	const int size = V;
	int *result = new int[this->V];
	result[0] = 0;//first color
	 bool *available = new bool[this->V];
	for (int av = 0; av < this->V; av++)
	{
		available[av] = true;
		if (av == 0) { continue; }
		result[av] = -1;
	}
	//coloring vertices
	for (int v = 1; v < this->V; v++)
	{
		std::list<int>::iterator i;
		for (i = this->adj[v].begin(); i != this->adj[v].end(); ++i)
		{
			if (result[*i] != -1)
			{
				available[result[*i]] = false;
			}
		}
		int cav;
		for (cav = 0; cav < this->V; cav++)
		{
			if (available[cav])
				break;
		}
		//available color found
		result[v] = cav;//colored
		for (i = adj[v].begin(); i != adj[v].end(); ++i)
		{
			available[result[*i]] = true;
		}
	}
	std::vector <int> colors;
	for (int i = 0; i < this->V; i++)
	{
		colors.push_back(result[i]);
	}
	return colors;
}

std::list <int> graph::get_neibourgs(int vertex)
{
	return this->adj[vertex];
}

map<int,int> graph::DSatur()
{
	map <int, int> nodes;
	map <int, std::list <int>> neibourghs;
	if (this->V==0) { return nodes; }
	//fill with vertices and their neibourghs from 1 to maxsize
	for (int i = 1; i <= this->V; i++)
	{
		neibourghs.insert(std::make_pair(i, this->get_neibourgs(i - 1)));
	}
	//find max degree-with most neibourghs and color it with the first color
	int degree = -1;
	int maxvertex = -1;
	for (std::map <int, std::list <int>>::iterator itr = neibourghs.begin(); itr != neibourghs.end(); itr++)
	{
		int j =itr->second.size();
		if (j > degree)
		{
			j = itr->second.size();
			degree = itr->second.size();
			maxvertex = itr->first;
		}
	}
	nodes[maxvertex] = 0;
	vector <int> todo;
	map <int, int> saturation_level;
	//edit except max vertex the saturation level to zero
	int k;
	for (int i = 1; i < this->V; i++)
	{
		k = nodes[i];
		if (i != maxvertex)
		{
			nodes[i] = -1;
			todo.push_back(i);
		}
	}
	for (int i = 1; i <= this->V; i++)
	{
		saturation_level[i] = 0;
	}
	saturation_level[maxvertex] = INT_MIN;//saturate to a very low level
	for (std::list <int>::iterator itr = neibourghs[maxvertex].begin(); itr != neibourghs[maxvertex].end(); itr++)
	{
		saturation_level[*itr] += 1;
	}
	//increase the saturation level of the neibourghs of the max vertex.
	while (!todo.empty())
	{
		int saturation = -1;
		int satur_vertex = -1;
		vector <int> saturation_colors;
		int k;
		for (map <int, int>::iterator i = saturation_level.begin(); i != saturation_level.end(); i++)
		{
			k = i->second;
			if (i->second > saturation)
			{
				saturation = i->second;
				satur_vertex = i->first;
				saturation_colors.clear();
				for (auto itr = neibourghs[satur_vertex].begin(); itr != neibourghs[satur_vertex].end(); itr++)
				{
					saturation_colors.push_back(nodes[*itr]);
				}
			}
		}
		for (vector <int>::iterator t = todo.begin(); t != todo.end(); t++)
		{
			if (*t == satur_vertex)
			{
				todo.erase(t); break;
			}
		}
		//find color which had been used rarely
		int lowest_color = 0;
		bool done = false;
		while (!done)
		{
			done = true;
			for (size_t i = 0, t = saturation_colors.size(); i < t; i++)
			{
				if (saturation_colors.at(i) == lowest_color)
				{
					lowest_color++;
					done = false;
				}
			}
		}

		//fill saturated vertex with color
		nodes[satur_vertex] = lowest_color;

		for (std::list <int>::iterator i = neibourghs[satur_vertex].begin(); i != neibourghs[satur_vertex].end(); i++)
		{
			if (saturation_level[*i] != INT_MIN)
			{
				saturation_level[*i] += 1;
			}
		}
		saturation_level[satur_vertex] = INT_MIN;
	}
	std::cout << "Algorithm fetching results......." << std::endl;
	return nodes;
}