
#include <vector>
#include <sstream>
#include "database.h"
#include "RLF.h"
#include "student.h"
#include "graph.h"
#include "vertex.h"
#include <string>
class handler
{
private:
	std::vector <student> students;
	std::vector <std::string> exams;
	std::vector <vertex> vertices;
	std::string fn;
	int size;
	graph *g;
	RLF* rlfalgo;
	int** algboard;
	std::vector <std::list <int>> findneibourghslist();
public:
	handler();
	void Init(std::string filename);
	void open_file(std::string fn);
	void show_students();
	void find_exams();
	int find_diff(std::string n1, std::string n2);
	void fill_board();
	size_t get_sign_ins();
	double findDensity();
	double find_Cv(int *sum);
	void calculate_statistics(int& max, int& min, int& med, double& mean, double& cv);
	void print_statistics();
	void design_graph();
	void first_fit();
	void find_occurences();
	void show_neibourghs();
	void print_vertices();
	void DSatur_Results();
	void Rlf_Results();
	void show_full_stats();
	void memory_freed();
};

void welcome_message();
