#include <iostream>
int main()
{
    srand(42);
    std::cout<<rand()<<std::endl;
    std::cout<<rand()<<std::endl;
    std::cout<<rand()<<std::endl;
}