#pragma once
#include <iostream>
#include <list>
class graph
{
private:
	int* result;
	bool* available;
	int V;
	std::list <int>* adj;
public:
	graph(int v);
	~graph();
	void free_temp();
	void add_connection(int s, int d);
	void coloring();
	void Datsur();
};

