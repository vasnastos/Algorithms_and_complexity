#include "vertex.h"
#include <algorithm>
#include <numeric>

vertex::vertex(std::string &c) :code(c) {}
vertex::~vertex() {}
void vertex::add_vertex(const int& v) { this->vertices.push_back(v); }
size_t vertex::collision_counter()
{
	return std::accumulate(this->vertices.begin(), this->vertices.end(), 0);
}
bool vertex::operator<(vertex& v) { return this->collision_counter() < v.collision_counter(); }
bool vertex::operator>(vertex& v) { return this->collision_counter() > v.collision_counter(); }
std::ostream& operator<<(std::ostream& os, const vertex& v)
{
     os << "*********************************** exam " << v.code << " ***********************" << std::endl;
	 int i = 1;
	 for (auto& x : v.vertices)
	 {
		 os << "\tcolission with registered vertex " << i << ":" << x << std::endl;
		 i++;
	 }
	 os << "***********************************************************************************" << std::endl;
	 return os;
}