﻿#include "handler.h"
#include <fstream>
#include <cmath>

//διαθέσιμα αρχεία προβλήματος
std::vector <std::string> files;

void available_files()
{
	std::ifstream is;
	std::string line;
	is.open("input.txt",std::ios::in);
	while (std::getline(is, line))
	{
		files.push_back(line);
	}
	is.close();
}

std::string select_file()
{
	int i=1;
	int choice;
	std::cout << "********************* Select File *********************" << std::endl;
	for (auto& x : files)
	{
		std::cout << i << "-" << x << std::endl;
		i++;
	}
	std::cout << "*******************************************************" << std::endl;
	std::cout << "Select your input file:";
	std::cin >> choice;
	while (choice<0 || choice>files.size())
	{
		std::cout << std::endl << "!!!!!Available options 0-" << files.size() << std::endl;
		std::cout << "Please Reenter your choice";
		std::cin >> choice;
	}
	return files.at(choice - 1);
}

int main_menu()
{
	int choice;
	std::cout << "********************** MENU ***********************" << std::endl;
	std::cout << "\t1-Show information per vertex" << std::endl;
	std::cout << "\t2-Statistics" << std::endl;
	std::cout << "\t3-First Fit" << std::endl;
	std::cout << "\t4-Datsur" << std::endl;
	std::cout << "\t5-RLF" << std::endl;
	std::cout << "\t6-Backtracking Datsur" << std::endl;
	std::cout << "\t7-Massive Solution" << std::endl;
	std::cout << "\t8-Find Neibourgs" << std::endl;
	std::cout << "\t9-Show all stats" << std::endl;
	std::cout << "\t10-Exit App" << std::endl;
	std::cout << "**************************************************" << std::endl<<std::endl;
	std::cout << "Select Algorithm sequence:";
	std::cin >> choice;
	return choice;
}

int main()
{
	handler h;
	available_files();
	h.Init(select_file());
	std::string warning = "Algorithm not implement yet";
	bool exitbutton = false;
	while(1)
	{
		std::cout << std::endl;
		int menu = main_menu();
		switch (menu)
		{
		case 1:
			h.print_vertices();
			break;
		case 2:
			h.print_statistics();
			break;
		case 3:
			h.first_fit();
			break;
		case 4:
			std::cout << warning << std::endl << std::endl;
			break;
		case 5:
			std::cout << warning << std::endl << std::endl;
			break;
		case 6:
			std::cout << warning << std::endl;
			break;
		case 7:
			std::cout << warning << std::endl;
			break;
		case 8:
			h.show_neibourghs();
			break;
		case 9:
			h.show_full_stats();
			break;
		case 10:
			exitbutton = true;
			break;
		default:
			std::cout << "Option " << menu << " is an invalid option!!Please try again choose a valid option" << std::endl;
			break;
		}
		if (exitbutton)
		{
			break;
		}
	}
	std::cout << std::endl;
	std::cout << "###############################" << std::endl;
	std::cout << "Program execution ended!!!Thank you for using the App" << std::endl;
	std::cout << "###############################" << std::endl;

	//destruct
	h.memory_freed();
	return 0;
}