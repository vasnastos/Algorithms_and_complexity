#include "graph.h"
graph::graph(int v) : V(v), adj(new std::list<int>[v]),result(nullptr),available(nullptr) {}
graph::~graph() { delete[] this->adj;}

void graph::add_connection(int s, int d)
{
	adj[s].push_back(d);
}

void graph::free_temp()
{
	delete[] this->result;
	delete[] this->available;
}

void graph::coloring()
{
	const int size = V;
	int *result = new int[this->V];
	result[0] = 0;//first color
	 bool *available = new bool[this->V];
	for (int av = 0; av < this->V; av++)
	{
		available[av] = true;
		if (av == 0) { continue; }
		result[av] = -1;
	}
	//coloring vertices
	for (int v = 1; v < this->V; v++)
	{
		std::list<int>::iterator i;
		for (i = this->adj[v].begin(); i != this->adj[v].end(); ++i)
		{
			if (result[*i] != -1)
			{
				available[result[*i]] = false;
			}
		}
		int cav;
		for (cav = 0; cav < this->V; cav++)
		{
			if (available[cav])
				break;
		}
		//available color found
		result[v] = cav;//colored
		for (i = adj[v].begin(); i != adj[v].end(); ++i)
		{
			available[result[*i]] = true;
		}
	}
	std::cout << std::endl << "****************************** Coring algorithm results ************************************" << std::endl;
	for (int u = 0; u < this->V; u++)
	{
		std::cout << "\t#Vertex " << u + 1 << "->Color:" << result[u] << std::endl;
	}
	std::cout << "*******************************************************************************************************" << std::endl;
}

std::list <int> graph::get_neibourgs(int vertex)
{
	return this->adj[vertex];
}

void graph::Datsur()
{

}