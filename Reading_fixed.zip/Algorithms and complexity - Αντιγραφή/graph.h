#pragma once
#include <iostream>
#include <list>
#include <map>
#include <vector>

using std::map;
using std::vector;

class graph
{
private:
	int* result;
	bool* available;
	int V;
	std::list <int>* adj;
	bool contains(int start,int dest);
public:
	graph(int v);
	~graph();
	void free_temp();
	void add_connection(int s, int d);
	std::list <int>& get_neibourgs(int vertex);
	std::vector <int> first_fit();
	map <int,int> DSatur();
};

