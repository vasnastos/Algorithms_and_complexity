﻿#include "RLF.h"

RLF::RLF(std::vector <std::list<int>>& vlc, int V) :graph(vlc),unprocessed(V), vertices(V),colors(new int[V]) {
	for (int i = 0; i < V; i++)
	{
		colors[i] = -1;
		
	}
	std::cout << graph.size();
}

int RLF::MaxDegreeVertex()
{
	int max = -1;
	int max_i = -1; 
	int check;
	for (int i = 0; i < this->vertices; i++)
	{
		check = this->graph.at(i).size();
		if (this->colors[i] == -1 && check > max)
		{
			max = this->graph.at(i).size();
			max_i = i;
		}
	}
	return max_i;
}

void RLF::UpdateNonNeibourghs(int cn)
{
	this->nonneibourghs.clear();
	for (int i = 0; i < this->vertices; i++)
	{
		if (this->colors[i] == -1)
		{
			this->nonneibourghs.insert(i);
		}
	}
	std::vector <int> deletetionvalues;
	for (int i = 0; i < this->vertices; i++)
	{
		if (this->colors[i] == cn)
		{
			set <int>::iterator j = this->nonneibourghs.begin();
			while(j!=this->nonneibourghs.end())
			{
				if (this->is_adjancent(i, *j))
				{
					deletetionvalues.push_back(*j);
				}
				int k = this->nonneibourghs.size();
				j++;
			} 
		}
	}
	int optional = deletetionvalues.size();
	for (auto& x : deletetionvalues)
	{
		this->nonneibourghs.erase(x);
	}
}

bool RLF::is_adjancent(int source, int target)
{
	list<int>::iterator i = this->graph.at(source).begin();
	list<int>::iterator end = this->graph.at(source).end();
	while (i != end)
	{
		if (*i == target)
		{
			return true;
		}
		i++;
	}
	return false;
}

int RLF::find_NonN_Vertex(int ColorNumber, int& Vic)
{
	int tmp_y, y=-1, temp;
	int* scanned = new int[this->vertices];
	Vic = 0;
	for (auto i = this->nonneibourghs.begin(); i != this->nonneibourghs.end(); i++)
	{
		tmp_y = *i;
		temp = 0;
		for (int l = 0; l < this->vertices; l++)
		{
			scanned[l] = 0;
		}
		for (int x = 0; x < this->vertices; x++)
		{
			if (this->colors[x] == ColorNumber)
			{
				for (int k = 0; k < this->vertices; k++)
				{
					if (this->colors[k] == -1 && scanned[k] == 0)
					{
						if (this->is_adjancent(x, k) && this->is_adjancent(tmp_y, k))
						{
							temp++;
							scanned[k] = 1;
						}
					}
				}
			}
		}
		if (temp > Vic)
		{
			Vic = temp;
			y = tmp_y;
		}
	}
	delete[] scanned;
	scanned = 0;
	return y;
}

int RLF::MaxDegreeInNN()
{
	int temp_y, temp, max = 0;
	for (set <int>::iterator i = this->nonneibourghs.begin(); i != this->nonneibourghs.end(); i++)
	{
		temp = 0;
		for (int j = 0; j < this->vertices; j++)
		{
			if (this->colors[j] == -1 && this->is_adjancent(*i, j))
			{
				temp++;
			}
		}
		if (temp > max)
		{
			max = temp;
			temp_y = *i;
		}
	}
	if (max == 0)
	{
		return *(this->nonneibourghs.begin());
	}
	else
	{
		return temp_y;
	}
}

std::vector <int> RLF::rlf()
{
	std::vector <int> coloring;
	int x, y;
	int vic = 0;
	int colornumber = -1;
	while (this->unprocessed > 0)
	{
		x = this->MaxDegreeVertex();
		colornumber++;
		this->unprocessed--;
		this->colors[x] = colornumber;
		this->UpdateNonNeibourghs(colornumber);
		while (!this->nonneibourghs.empty())
		{
			y = find_NonN_Vertex(colornumber,vic);
			if (vic == 0)
			{
				y = MaxDegreeInNN();
			}
			this->colors[y] = colornumber;
			this->unprocessed--;
			UpdateNonNeibourghs(colornumber);
		}
	}
	for (int i = 0; i < this->vertices; i++)
	{
		coloring.push_back(colors[i]);
	}
	return coloring;
}