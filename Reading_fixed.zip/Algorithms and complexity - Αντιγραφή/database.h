#pragma once
#include <string>
#include <vector>
#include "statstruct.cpp"


void open_db();
bool is_in(std::string filename);
bool enroll_data(std::string filename);
void insert_data(std::string f, double d, int mn, int md, int mx, double men, double c);
void insert_coloring_data(std::string file);
void update_first_fit_data(std::string file, int ff);
void update_dsatur_data(std::string file, int ds);
void update_Rlf_data(std::string file, int r);
void update_backtrackingdsatur_data(std::string file, int bds);
std::vector <stats> get_records();