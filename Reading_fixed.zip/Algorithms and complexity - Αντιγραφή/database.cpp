#include "sqlite3.h"
#include "database.h"


std::string db_name = "graph_coloring.db";

void open_db()
{
	sqlite3* db = nullptr;
	std::string sql;
	sqlite3_stmt* q = nullptr;
	char* errmsg = nullptr;
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_free(errmsg);
		sqlite3_close(db);
		return;
	}
	else
	{
		//Database open
	}
	sql = "create table if not exists stats(file varchar(40),density double,min integer,median integer,max integer,mean double,cv double,primary key(file))";
	res=sqlite3_exec(db, sql.c_str(), 0, 0, &errmsg);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_free(errmsg);
		sqlite3_close(db);
	}
	sql = "create table if not exists algorithms(file varchar(60),first_fit integer,DSatur integer,Rlf integer,BDSatur integer,primary key(file))";
	res = sqlite3_exec(db, sql.c_str(), 0, 0,&errmsg);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_free(errmsg);
		sqlite3_close(db);
		return;
	}
}

bool enroll_data(std::string file)
{
	sqlite3* db = nullptr;
	sqlite3_stmt* q = nullptr;
	std::string sql = "select * from algorithms where file=?";
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return false;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return false;
	}
	sqlite3_bind_text(q, 1, file.c_str(), -1, SQLITE_STATIC);
	bool result = sqlite3_step(q) == SQLITE_ROW;
	sqlite3_close(db);
	return result;
}

void insert_coloring_data(std::string file)
{
	if (enroll_data(file)) { return; }
	sqlite3* db = nullptr;
	std::string sql="insert into algorithms(file) values(?)";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout<<sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_text(q, 1, file.c_str(), -1,SQLITE_STATIC);
	sqlite3_step(q);
	sqlite3_close(db);
}

void update_first_fit_data(std::string file, int ff)
{
	sqlite3* db = nullptr;
	std::string sql = "update algorithms set first_fit=? where file=?";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_int(q, 1, ff);
	sqlite3_bind_text(q, 2, file.c_str(), -1, SQLITE_STATIC);
	sqlite3_step(q);
	sqlite3_close(db);
}

void update_dsatur_data(std::string file, int ds)
{
	sqlite3* db = nullptr;
	sqlite3_stmt* q = nullptr;
	std::string sql = "update algorithms set DSatur=? where file=?";
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db);
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_text(q, 1, file.c_str(), -1, nullptr);
	sqlite3_bind_int(q, 2, ds);
	sqlite3_step(q);
	sqlite3_close(db);
}

void update_Rlf_data(std::string file, int r)
{
	sqlite3* db = nullptr;
	std::string sql = "update algorithms set Rlf=? where file=?";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_text(q, 1, file.c_str(), -1, nullptr);
	sqlite3_bind_int(q, 2, r);
	sqlite3_step(q);
	sqlite3_close(db);
}

void update_backtrackingdsatur_data(std::string file, int bds)
{
	sqlite3* db = nullptr;
	sqlite3_stmt* q = nullptr;
	std::string sql = "update algorithms set BDSatur=? where file=?";
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_text(q, 1, file.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_int(q, 2, bds);
	sqlite3_step(q);
	sqlite3_close(db);
}

bool is_in(std::string filename)
{
	sqlite3* db = nullptr;
	sqlite3_stmt* q=nullptr;
	std::string sql = "select * from stats where file=?";
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db);
		sqlite3_close(db);
		return false;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return false;
	}
	sqlite3_bind_text(q, 1, filename.c_str(), -1, SQLITE_STATIC);
	bool reslt=sqlite3_step(q)==SQLITE_ROW;
	sqlite3_close(db);
	return reslt;
}

void insert_data(std::string f,double d,int mn,int md,int mx,double men,double c)
{
	if (is_in(f)) { return; }
	sqlite3* db = nullptr;
	std::string sql = "insert into stats(file,density,min,median,max,mean,cv) values(?,?,?,?,?,?,?)";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res=sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_text(q, 1, f.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_double(q, 2, d);
	sqlite3_bind_int(q, 3, mn);
	sqlite3_bind_int(q, 4, md);
	sqlite3_bind_int(q, 5, mx);
	sqlite3_bind_double(q, 6, men);
	sqlite3_bind_double(q, 7, c);
	sqlite3_step(q);
	sqlite3_close(db);
}

std::vector <stats> get_records()
{
	std::vector <stats> records;
	sqlite3* db = nullptr;
	std::string sql = "select * from stats";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return records;
	}
	res=sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return records;
	}
	while (sqlite3_step(q) == SQLITE_ROW)
	{
		stats s;
		s.file = (const char*)sqlite3_column_text(q, 0);
		s.density = sqlite3_column_double(q, 1);
		s.min = sqlite3_column_int(q, 2);
		s.median = sqlite3_column_int(q, 3);
		s.max = sqlite3_column_int(q, 4);
		s.mean = sqlite3_column_double(q, 5);
		s.cv = sqlite3_column_double(q, 6);
		records.push_back(s);
	}
	sqlite3_close(db);
	return records;
}