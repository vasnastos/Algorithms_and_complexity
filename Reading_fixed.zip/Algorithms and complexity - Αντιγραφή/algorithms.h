#pragma once
class algorithms
{
};

