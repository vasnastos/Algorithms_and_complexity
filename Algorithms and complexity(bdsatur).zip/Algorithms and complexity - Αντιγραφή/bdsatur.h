#pragma once
#include <list>
#include <map>
#include <iostream>
#include <set>
#include <algorithm>
#include <vector>
class bdsatur
{
private:
	std::vector <std::list <int>> graph;
	int vertices;
	std::map <int, int> colors;
	int previous_saturation_level;
	std::vector <int> processing;
	std::vector <int> saturation_level;
	std::set <int> resval;
	int max_available_colors;
	int Max_Vertex();
	void reset(int vertex);
	int satur_vertex();
	bool safe_coloring(int c,int i);
	bool coloring();
public:
	bdsatur(std::vector <std::list <int>>& g);
	~bdsatur();
	void printing();
};

