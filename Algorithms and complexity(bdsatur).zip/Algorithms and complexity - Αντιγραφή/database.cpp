#include "sqlite3.h"
#include "database.h"
#include <fstream>


std::string db_name = "graph_coloring.db";
std::string backupdb = "graph_coloring_update.db";

void open_db()
{
	sqlite3* db = nullptr;
	std::string sql;
	sqlite3_stmt* q = nullptr;
	char* errmsg = nullptr;
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_free(errmsg);
		sqlite3_close(db);
		return;
	}
	else
	{
		//Database open
	}
	sql = "create table if not exists stats(file varchar(40),density double,min integer,median integer,max integer,mean double,cv double,primary key(file))";
	res=sqlite3_exec(db, sql.c_str(), 0, 0, &errmsg);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_free(errmsg);
		sqlite3_close(db);
	}
	sql = "create table if not exists algorithms(file varchar(60),vertices integer,first_fit integer,DSatur integer,Rlf integer,BDSatur integer,primary key(file))";
	res = sqlite3_exec(db, sql.c_str(), 0, 0,&errmsg);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_free(errmsg);
		sqlite3_close(db);
		return;
	}
	sqlite3_errmsg(db);
	sqlite3_close(db);
}

bool enroll_data(std::string file)
{
	sqlite3* db = nullptr;
	sqlite3_stmt* q = nullptr;
	std::string sql = "select * from algorithms where file=?";
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return false;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return false;
	}
	sqlite3_bind_text(q, 1, file.c_str(), -1, SQLITE_STATIC);
	bool result = sqlite3_step(q) == SQLITE_ROW;
	sqlite3_close(db);
	return result;
}

void insert_coloring_data(std::string file)
{
	if (enroll_data(file)) { return; }
	sqlite3* db = nullptr;
	std::string sql="insert into algorithms(file) values(?)";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout<<sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_text(q, 1, file.c_str(), -1,SQLITE_STATIC);
	sqlite3_step(q);
	sqlite3_close(db);
}

void update_vertices(std::string file, int v)
{
	sqlite3* db=nullptr;
	sqlite3_stmt* q = nullptr;
	std::string sql = "update algorithms set vertices=? where file=?";
	int res = sqlite3_open(backupdb.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_int(q, 1, v);
	sqlite3_bind_text(q, 2, file.c_str(), -1, SQLITE_STATIC);
	sqlite3_step(q);
	sqlite3_close(db);
}

void update_first_fit_data(std::string file, int ff)
{
	sqlite3* db = nullptr;
	std::string sql = "update algorithms set first_fit=? where file=?";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(backupdb.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_int(q, 1, ff);
	sqlite3_bind_text(q, 2, file.c_str(), -1, SQLITE_STATIC);
	sqlite3_step(q);
	sqlite3_close(db);
}

void update_dsatur_data(std::string file, int ds)
{
	sqlite3* db = nullptr;
	sqlite3_stmt* q = nullptr;
	std::string sql = "UPDATE algorithms SET DSatur=? WHERE file=?";
	int res = sqlite3_open(backupdb.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_int(q, 1, ds);
	sqlite3_bind_text(q, 2, file.c_str(), -1, SQLITE_STATIC);
	sqlite3_step(q);
	sqlite3_close(db);
}

void update_Rlf_data(std::string file, int r)
{
	sqlite3* db = nullptr;
	std::string sql = "update algorithms set Rlf=? where file=?";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_text(q, 1, file.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_int(q, 2, r);
	sqlite3_step(q);
	sqlite3_close(db);
}

void update_backtrackingdsatur_data(std::string file, int bds)
{
	sqlite3* db = nullptr;
	sqlite3_stmt* q = nullptr;
	std::string sql = "update algorithms set BDSatur=? where file=?";
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cout << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_text(q, 1, file.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_int(q, 2, bds);
	sqlite3_step(q);
	sqlite3_close(db);
}

bool is_in(std::string filename)
{
	sqlite3* db = nullptr;
	sqlite3_stmt* q=nullptr;
	std::string sql = "select * from stats where file=?";
	int res = sqlite3_open(backupdb.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return false;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return false;
	}
	sqlite3_bind_text(q, 1, filename.c_str(), -1, SQLITE_STATIC);
	bool reslt=sqlite3_step(q)==SQLITE_ROW;
	sqlite3_close(db);
	return reslt;
}

void insert_data(std::string f,double d,int mn,int md,int mx,double men,double c)
{
	if (is_in(f)) {return; }
	sqlite3* db = nullptr;
	std::string sql = "insert into stats(file,density,min,median,max,mean,cv) values(?,?,?,?,?,?,?)";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(backupdb.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res=sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	sqlite3_bind_text(q, 1, f.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_double(q, 2, d);
	sqlite3_bind_int(q, 3, mn);
	sqlite3_bind_int(q, 4, md);
	sqlite3_bind_int(q, 5, mx);
	sqlite3_bind_double(q, 6, men);
	sqlite3_bind_double(q, 7, c);
	if (sqlite3_step(q) != SQLITE_ROW) { std::cout << sqlite3_errmsg(db) << std::endl; }
	sqlite3_close(db);
}

std::vector <stats> get_records()
{
	std::vector <stats> records;
	sqlite3* db = nullptr;
	std::string sql = "select * from stats";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(db_name.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return records;
	}
	res=sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return records;
	}
	while (sqlite3_step(q) == SQLITE_ROW)
	{
		stats s;
		s.file = (const char*)sqlite3_column_text(q, 0);
		s.density = sqlite3_column_double(q, 1);
		s.min = sqlite3_column_int(q, 2);
		s.median = sqlite3_column_int(q, 3);
		s.max = sqlite3_column_int(q, 4);
		s.mean = sqlite3_column_double(q, 5);
		s.cv = sqlite3_column_double(q, 6);
		records.push_back(s);
	}
	sqlite3_close(db);
	return records;
}

void save_DSatur()
{
	sqlite3* db = nullptr;
	std::string sql = "select file,DSatur from algorithms";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(backupdb.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	std::string filename;
	int ds;
	std::fstream fs;
	fs.open("RESULT_SETS/save_DS.out", std::ios::out);
	fs << "DSATUR GRAPH COLORING ALGORITHMS DATA RESULTS" << std::endl;
	fs << "ALGORITHMS AND COMPLEXITY COURSE" << std::endl;
	fs << "DATASHEET USED:TORONTO.ZIP" << std::endl;
	fs << "TOTAL FILES USED:13" << std::endl;
	fs << "\t\t" << "DSATUR RESULTS" << std::endl;
	fs << "##############################################################" << std::endl << std::endl;
	fs << "Filename      Colors used" << std::endl;
	while (sqlite3_step(q) == SQLITE_ROW)
	{
		filename=(const char *)sqlite3_column_text(q,0);
		ds=sqlite3_column_int(q,1);
		fs << filename << "      " << ds << std::endl;
	}
	sqlite3_close(db);
	fs.close();
}

void save_First_Fit()
{
	sqlite3* db=nullptr;
	std::string sql="select file,vertices,first_fit from algorithms";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(backupdb.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	std::string filename;
	int ff,v;
	std::fstream fs;
	fs.open("RESULT_SETS/save_First_Fit.out", std::ios::out);
	fs << "First Fit COLORING ALGORITHMS DATA RESULTS" << std::endl;
	fs << "ALGORITHMS AND COMPLEXITY COURSE" << std::endl;
	fs << "DATASHEET USED:TORONTO.ZIP" << std::endl;
	fs << "File Created at" << __TIME__ << "--" << __DATE__ << std::endl;
	fs << "TOTAL FILES USED:13" << std::endl;
	fs << "\t\t" << "FIRST FIT RESULTS" << std::endl;
	fs << "##############################################################" << std::endl << std::endl;
	fs << "Filename      Vertices      Colors used" << std::endl;
	while (sqlite3_step(q) == SQLITE_ROW)
	{
		filename =(const char *) sqlite3_column_text(q, 0);
		v = sqlite3_column_int(q, 1);
		ff = sqlite3_column_int(q, 2);
		fs << filename << "      " <<v<<"          "<<ff<< std::endl;
	}
	sqlite3_close(db);
	fs.close();
}

void save_Statistics()
{
	sqlite3* db = nullptr;
	std::string sql = "select * from stats";
	sqlite3_stmt* q = nullptr;
	int res = sqlite3_open(backupdb.c_str(), &db);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	res = sqlite3_prepare_v2(db, sql.c_str(), -1, &q, nullptr);
	if (res != SQLITE_OK)
	{
		std::cerr << sqlite3_errmsg(db) << std::endl;
		sqlite3_close(db);
		return;
	}
	std::string fn;
	int vertices;
	int max, min, median;
	double dens, cv;
	std::fstream fs;
	fs.open("RESULT_SETS/Statistics.out",std::ios::out);
	fs << "GRAPH COLORING PROBLEM " << std::endl;
	fs << "DATASHEET:TORONTO.ZIP" << std::endl;
	fs << "FILE CREATED:" << __DATE__ << "---" << __TIME__ << std::endl;
	fs << "ALGORITHMS USED:FIRST_FIT--DSATUR--RLF--BACKTRACKING DSATUR" << std::endl;
	fs << "\t\t\tStatistics" << std::endl;
	fs << "##############################################################" << std::endl;
	fs << "FILENAME      V      DENS       MIN      MEDIAN      MAX      CV" << std::endl;
	while (sqlite3_step(q) == SQLITE_ROW)
	{
		fn = (const char*)sqlite3_column_text(q, 0);
		vertices = sqlite3_column_int(q, 1);
		dens = sqlite3_column_double(q, 2);
		min = sqlite3_column_int(q, 3);
		median = sqlite3_column_int(q, 4);
		max = sqlite3_column_int(q, 5);
		cv = sqlite3_column_double(q, 6);
		fs << fn << "      " << vertices << "      " << dens << "     " << min << "      " << median << "      " << max << "      " << cv << std::endl;
	}
	sqlite3_close(db);
	fs.close();
}