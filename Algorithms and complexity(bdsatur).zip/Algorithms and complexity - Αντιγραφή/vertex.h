#pragma once
#include <iostream>
#include <vector>
class vertex
{
private:
	std::string code;
	std::vector <int> vertices;
public:
	vertex(std::string &c);
	~vertex();
	std::string getCode()const;
	size_t collision_counter()const;
	std::vector <int>& connections();
	bool operator<(vertex& v);
	bool operator>(vertex& v);
	bool operator==(const vertex& v)const;
	void add_vertex(const int& v);
	friend std::ostream& operator<<(std::ostream& os, const vertex& v);
};

