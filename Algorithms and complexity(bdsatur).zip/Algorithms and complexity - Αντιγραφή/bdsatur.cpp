#include "bdsatur.h"

bdsatur::bdsatur(std::vector <std::list <int>>& g) :graph(g), vertices(g.size())
{
	for (int i = 0; i < this->vertices; i++)
	{
		saturation_level.push_back(0);
		colors[i] = -1;
		processing.push_back(i);
	}
	std::cout << std::endl << "Give Max number of colors you want to use:";
	std::cin >> this->max_available_colors;
	int startvertex = this->Max_Vertex();
	colors[startvertex] = 0;
}

bdsatur::~bdsatur()
{

}

int bdsatur::Max_Vertex()
{
	int degree = -1;
	int max_vertex = -1;
	int countpos=0;
	for (auto& x : this->graph)
	{
		if (x.size() > degree)
		{
			degree = x.size();
			max_vertex = countpos;
		}
		countpos++;
	}
	return max_vertex;
}

void bdsatur::reset(int vertex)
{
	colors[vertex] = -1;
	for (auto& x : this->graph[vertex])
	{
		this->saturation_level[x] -= 1;
	}
	saturation_level[vertex] = previous_saturation_level;
	this->processing.push_back(vertex);
	this->resval.insert(vertex);
}

int bdsatur::satur_vertex()
{
	int saturation = -1;
	int satur_vertex = -1;
	for (int i = 0,t=this->saturation_level.size(); i <t; i++)
	{
		if (this->saturation_level.at(i) > saturation && this->resval.find(i)==this->resval.end())
		{
			satur_vertex = i;
			saturation = this->saturation_level.at(i);
		}
	}
	for (std::list <int>::iterator i = this->graph[satur_vertex].begin(); i != this->graph[satur_vertex].end(); i++)
	{
		this->saturation_level[*i]++;
	}
	this->saturation_level[satur_vertex] = INT_MIN;
	for (auto x = this->processing.begin(); x != this->processing.end(); x++)
	{
		if (*x == satur_vertex)
		{
			this->processing.erase(x);
		}
	}
	return satur_vertex;
}

bool bdsatur::safe_coloring(int c,int i)
{
		for (std::list <int>::iterator j = this->graph[c].begin(); j != this->graph[c].end(); j++)
		{
			if (colors[*j] != i)
			{
				colors[c] = i;
				return true;
			}
		}
	return false;
}


bool bdsatur::coloring()
{
	if (this->max_available_colors == 0) { return false; }
	if (this->processing.empty()) { return true; }
	int checkvertex = this->satur_vertex();
	for (int color = 0; color <= this->max_available_colors; color++)
	{
		if (safe_coloring(checkvertex,color))
		{
			this->resval.clear();
			if (coloring()) { return true; }
			this->reset(checkvertex);//Backtrack
		}
	}
	return false;
}

void bdsatur::printing()
{
	std::cout << "########### BDSATUR EXECUTED #########################" << std::endl;
	if (!this->coloring())
	{
		std::cout << "Can't not color the vertices with " << this->max_available_colors << " colors" << std::endl;
	}
	else
	{
		for (auto& v : this->colors)
		{
			std::cout << "\t#Vertex:" << v.first << "-->" << v.second << std::endl;
		}
	}
	std::cout << "######################################################" << std::endl;
}