﻿#include "handler.h"
#include "bdsatur.h"
#include <fstream>
#include <numeric>
#include <algorithm>

using std::vector;
using std::list;

std::string root = "datasheets/";

void welcome_message()
{
	std::cout << "**************** Welcome graph coloring algorithms Application *********************************" << std::endl;
	std::cout << "The graph coloring problem is an NP ‐ hard combination optimization problem. It involves assigning a color to each\n";
	std::cout << "vertex of a graph so that adjacent vertices\n";
	std::cout << "are colored differently, while at the same time the minimum number of different colors is used. In the present work,\n";
	std::cout << " the implementation of four graph coloring algorithms\n";
	std::cout << "and their application to known problems from the literature is requested." << std::endl;
	std::cout << "*************************************************************************************************" << std::endl << std::endl;
}
int handler::vertex_exists(const vertex &v)
{
	int i = 0;
	for (std::vector <vertex>::iterator itr = this->vertices.begin(); itr != this->vertices.end(); itr++)
	{
		if (*itr == v)
		{
			return i;
		}
		i++;
	}
	return -1;
}
handler::handler():g(nullptr),size(0),fn(""),rlfalgo(nullptr) {
	welcome_message();
	open_db();
}

vector <list <int>> handler::findneibourghslist()
{
	vector <list <int>> neibourghs;
	const int verticesize = this->exams.size();
	for (int i = 0; i < verticesize; i++)
	{
		neibourghs.push_back(g->get_neibourgs(i));
	}
	return neibourghs;
}

void handler::Init(std::string filename)
{
	this->students.clear();
	this->exams.clear();
	this->vertices.clear();
	this->fn = filename;
	this->open_file(filename);
	this->find_exams();
	this->size = this->exams.size();
	update_vertices(this->fn, size);
	this->g = new graph(this->size);
	this->find_occurences();
	vector <list <int>> vrb=this->findneibourghslist();
	rlfalgo = new RLF(vrb,this->size);
}

void handler::open_file(std::string fn)
{
	std::string line;
	std::ifstream is;
	is.open(root+fn, std::ios::in);
	if (!is.is_open())
	{
		std::cerr << "File did not open!!!" << std::endl;
		return;
	}
	std::string word;
	int id = 1;
	std::vector <std::string> a_show;
	while (std::getline(is, line))
	{
		std::istringstream ss(line);
		student s(fn, id);
		while (ss >> word)
		{
			s.add_lesson(word);
		}
		students.push_back(s);
	}
	is.close();
}

void handler::find_exams()
{
	for (auto& x : students)
	{
		bool found = false;
		std::vector <std::string> exms = x.getExams();
		for (auto& k : exms)
		{
			bool found = false;
			for (auto& x : exams)
			{
				if (k == x)
				{
					found = true;
					break;
				}
			}
			if (!found)
			{
				exams.push_back(k);
				vertex v(k);
				this->vertices.push_back(k);
			}
		}
	}
}

void handler::show_students()
{
	for (auto& y : students)
	{
		std::cout << "*********************************************************" << std::endl;
		std::cout << y << std::endl;
		std::cout << "*********************************************************" << std::endl << std::endl;
	}
}

int handler::find_diff(std::string n1, std::string n2)
{
	int counter = 0;
	for (auto& x : students)
	{
		if (x.is_in(n1) && x.is_in(n2))
		{
			counter++;
		}
	}
	return counter;
}

void handler::DSatur_Results()
{
	std::map <int, int> results = g->DSatur();
	std::cout << "\tTotal exams:" << this->exams.size() << std::endl;
	int max = INT_MIN;
	std::cout << "*************************************** DSatur Coloring Algorithm results ******************************" << std::endl;
	int i;
	for (std::map <int, int>::iterator itr = results.begin(); itr != results.end(); itr++)
	{
		i = itr->first;
		std::cout << "\t#Vertex:" <<this->exams[i]  << "->" << itr->second << std::endl;
		if (itr->second > max)
		{
			max = itr->second;
		}
	}
	std::cout << "*********************************************************************************************************" << std::endl;
	std::cout << "\tTotal colors used:" << max + 1 << std::endl << std::endl;
	update_dsatur_data(this->fn, max+1);
}

int sum(int s, const vertex& v) { return s + v.collision_counter(); }

double handler::findDensity()
{
	int summary = std::accumulate(this->vertices.begin(), this->vertices.end(), 0, sum);
	return (double)summary / pow(size, 2);
}

int handler::get_exam_index(const std::string &exam)
{
	for (int i = 0, t = this->exams.size(); i < t; i++)
	{
		if (this->exams.at(i) == exam)
		{
			return i;
		}
	}
	return -1;
}

double handler::find_Cv(int *sum)
{
	double avg = std::accumulate(sum, sum + size, 0) / (double)size;
	double calc = 0.0;
	for (int i = 0; i < size; i++)
	{
		calc += pow((double)sum[i] - avg, 2);
	}
	calc /= size - 1.0;
	return (sqrt(calc) / avg) * 100.0;
}

void handler::calculate_statistics(int& max, int& min, int& med, double& mean, double& cv)
{
	const int size = this->vertices.size();
	int* sum = new int[size];
	for (int i = 0; i < size; i++)
	{
		int k = this->vertices.at(i).collision_counter();
		sum[i] = k;
	}
	max = *std::max_element(sum, sum + size);
	min = *std::min_element(sum,sum+size);
	mean = (double)std::accumulate(sum,sum+size,0) / size;
	std::sort(sum, sum + size);
	med = sum[(size / 2) + 1];
	cv = find_Cv(sum);
	delete[] sum;
}

void handler::print_statistics()
{
	int max, min, med;
	double mean, dens = this->findDensity(), cv;
	std::cout.precision(4);
	this->calculate_statistics( max, min, med, mean, cv);
	std::cout << "************************* Stats ***********************" << std::endl;
	std::cout << "\tTotal exams:" << exams.size() << std::endl;
	std::cout << "\tDensity:" << dens << std::endl;
	std::cout << "\tMax:" << max << std::endl;
	std::cout << "\tMin:" << min << std::endl;
	std::cout << "\tMedian:" << med << std::endl;
	std::cout << "\tMean:" << mean << std::endl;
	std::cout << "\tCV(=coefficient of variation):" << cv << "%" << std::endl;
	insert_data(this->fn, dens, min, med, max, mean, cv);
	std::cout << "*******************************************************" << std::endl;
}

void handler::first_fit()
{
	std::vector <int> ff = g->first_fit();
	std::cout << "\tTotal Vertices:" << ff.size()<<std::endl;
	std::cout << std::endl << "****************************** First Fit algorithm results ************************************" << std::endl;
	for (int i = 0, t = ff.size(); i < t; i++)
	{
		std::cout << "\t#Vertex:" << this->exams[i] << "->" << ff.at(i) << std::endl;
	}
	std::cout << "************************************************************************************************************" << std::endl;
	std::cout << "\tTotal Colors Used:" <<(*std::max_element(ff.begin(),ff.end()))+1 <<std::endl << std::endl;
	update_first_fit_data(this->fn,(*std::max_element(ff.begin(), ff.end())) + 1);
}

void handler::find_occurences()
{
	std::vector <std::string> data;
	int pos;
	for (auto& x : students)
	{
		data = x.getExams();
		for (auto& y : data)
		{
			int i = this->vertex_exists(y);
			for (auto& k : data)
			{
				if (k == y) continue;
				pos = this->get_exam_index(k);
				this->vertices.at(i).add_vertex(pos);
				g->add_connection(i, pos);
			}
		}
	}
}

void handler::print_vertices()
{
	for (auto itr = vertices.begin(); itr != vertices.end(); itr++)
	{
		std::cout << *itr << std::endl;
	}
}

size_t handler::get_sign_ins()
{
	size_t counter = 0;
	for (auto& x : students)
	{
		counter += x.lessons_enrolled_in();
	}
	return counter;
}

void handler::backtracking_DSatur()
{
	vector <list<int>> neibourghs = this->findneibourghslist();
	bdsatur b(neibourghs);
	b.printing();
}

void handler::show_neibourghs()
{
	std::cout << std::endl << "******************************** Connecetd Graph Vertices *************************************" << std::endl;
	for (int i = 0, t = exams.size(); i < t; i++)
	{
		std::cout << "Exam " << i + 1 << "->" << exams.at(i)<<":" << "\t";
		std::list <int> conn_vertices = g->get_neibourgs(i);
		for (std::list <int>::iterator itr = conn_vertices.begin(); itr != conn_vertices.end(); itr++)
		{
			std::cout << exams[*itr] << "\t";
		}
		std::cout << std::endl;
	}
	std::cout << "************************************************************************************************" << std::endl;
}

void handler::memory_freed()
{
	g->free_temp();
	delete g;
	delete rlfalgo;
	rlfalgo = 0;
	g = 0;
}

void handler::show_full_stats()
{
	std::vector <stats> records = get_records();
	std::cout << "********************************** File Stats *********************************************" << std::endl;
	for (std::vector <stats>::iterator itr = records.begin(); itr != records.end(); itr++)
	{
		std::cout << itr->file << "\t" << itr->density << "\t" << itr->min << "\t" << itr->max << "\t" << itr->median << "\t" << itr->mean << "\t" << itr->cv << std::endl;
	}
	std::cout << "********************************************************************************************" << std::endl;
}

void handler::Rlf_Results()
{
	std::vector <int> colors= rlfalgo->rlf();
	std::cout << "\tTotal Vertices:" << this->exams.size() << std::endl;
	std::cout << "************************** RLF Results ***************************************" << std::endl;
	for (int i = 0, t = colors.size(); i < t; i++)
	{
		std::cout << "\t#Vertex:" << this->exams[i] << "->" << colors[i] << std::endl;
	}
	std::cout << "*******************************************************************************" << std::endl << std::endl;
	int total_colors = *std::max_element(colors.begin(), colors.end()) + 1;
	std::cout << "\tTotal Colors Used:" << total_colors << std::endl;
	update_Rlf_data(this->fn, total_colors);
}

void handler::massive_solution()
{

}